import {validacion} from "../js/validaciones_formulario2.js";

document.addEventListener("DOMContentLoaded",e=>{
    validacion();
});