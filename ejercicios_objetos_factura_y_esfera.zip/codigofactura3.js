﻿class Empresa {
	constructor(nif,nombre,direccion,telefono){
	this.nif=nif;
	this.nombre=nombre;
	this.direccion=direccion;
	this.telefono=telefono;
	}
};

class Cliente {
	constructor(numcli,dnicli,nomcli,dircli,cp,ciudad,provincia){
	this.numcli=numcli;
	this.dnicli=dnicli;
	this.nomcli=nomcli;
	this.dircli=dircli;
	this.cp=cp;
	this.ciudad=ciudad;
	this.provincia=provincia;
	}
  };

class Productos{ 
	constructor(descripcion,unidades,precio){
		this.descripcion=descripcion;
		this.unidades=unidades;
		this.precio=precio;
	}
}
class DatosFactura {
	constructor(Empresa,Cliente){
		this.Empresa=Empresa;
		this.Cliente=Cliente;
		}
	};

class Factura extends DatosFactura{
	constructor(Empresa,Cliente,importetotal,formapago){
		super(Empresa,Cliente);
		this.importetotal=importetotal;
		this.formapago=formapago;
	};
	total(productos) {
		for(var i=0; i<productos.length; i++) {
			document.write(productos[i].unidades + " unidades de "+ 
			productos[i].descripcion+  " a precio "+ 
			productos[i].precio+" representando un subtotal de "+
			productos[i].precio*productos[i].unidades+"<br>");
			console.log(productos[i].unidades + " unidades de "+ 
			productos[i].descripcion+  " a precio "+ 
			productos[i].precio+" representando un subtotal de "+
			productos[i].precio*productos[i].unidades+"<br>");
		  this.importetotal += productos[i].unidades * productos[i].precio;
		} 
		console.log("TOTAL = " + this.importetotal + " euros"); 		
  document.write("TOTAL = " + this.importetotal + " euros"); 
  }
  
}



  
