package Ejerciciosiniciales;

import javax.swing.JOptionPane;

public class Main {

	public static void main(String[] args) {
		Cuenta cuenta = new Cuenta("Cristobal",5.98);

		
			
			int opcion;
			do {
				opcion = menu();
				
				switch (opcion) {
				case 0: // Ha elegido abandonar la aplicación
					System.out.println("HAS ABANDONADO LA APLICACIÓN.");
					break;
				case 1: // Ingresar Cantidad
					cuenta.ingresar();
					
					break;
				case 2: // Retirar Cantidad
					cuenta.retirar();
					
					break;

				default:
					System.out.println("Opción no válida");
				}
				
				// El bucle se repetirá mientras no se pulse la opción de salir.
			} while (opcion != 0);
		}
		
		public static int menu () {
			String strMenu = "\n\nMenú"
					+ "\n0.- Salir"
					+ "\n1.- Añadir Cantidad"
				    + "\n2.- Retirar Cantidad"
				    
					+ "\n\nIntroduzca su opción: ";
			// Muestro el menú y pido una opción al usuario
			int opcionUsuario = Integer.parseInt(JOptionPane.showInputDialog(strMenu));
			// Devuelvo la opción seleccionada
			return opcionUsuario;
		}
		

	}

