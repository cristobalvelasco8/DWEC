package Ejerciciosiniciales;

import javax.swing.JOptionPane;

public class Cuenta {

	String titular;
	Double cantidad;
	


	public Cuenta(String titular, Double cantidad) {
		// TODO Auto-generated constructor stub
		this.titular= titular;
		this.cantidad= cantidad;
	}


	public String getTitular() {
		return titular;
	}

	public void setTitular(String titular) {
		this.titular = titular;
	}

	public Double getCantidad() {
		return cantidad;
	}

	public void setCantidad(Double cantidad) {
		this.cantidad = cantidad;
	}

	@Override
	public String toString() {
		return "Cuenta [titular=" + titular + ", cantidad=" + cantidad + "]";
	}

public void ingresar() {
	Double cantidad = Double.parseDouble(JOptionPane.showInputDialog("Introduce la cantidad"));
	
	if (cantidad <= 0) {
		System.exit(0);
	} else {
			 this.cantidad+=cantidad;
		}
	System.out.println("La cantidad es" + " " + getCantidad());
	}

public void retirar() {
	Double cantidad = Double.parseDouble(JOptionPane.showInputDialog("Retirar la cantidad"));
	  if (this.cantidad - cantidad < 0) {
          this.cantidad = (double) 0;
      } else {
          this.cantidad -= cantidad;
      }
    
    System.out.println("La cantidad después del retiro es" + " " + getCantidad());
}





}

